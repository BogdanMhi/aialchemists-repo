import os

PROJECT_ID = os.environ.get("PROJECT_ID")
DATABASE_ID = os.environ.get("DATABASE_ID")
AZURE_OPENAI_API_KEY = os.environ.get("AZURE_OPENAI_API_KEY")
AZURE_OPENAI_ENDPOINT = os.environ.get("AZURE_OPENAI_ENDPOINT")