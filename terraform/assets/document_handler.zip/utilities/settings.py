import os

PROJECT_ID = os.environ.get("PROJECT_ID")